import { AtisGenerator } from '@/components/AtisGenerator';
import type { AtisContext } from '@/components/AtisGenerator';
import { AirlineLookup } from '@/components/AirlineLookup';
import { PhraseGenerator } from '@/components/PhraseGenerator';
import type { StatusValue, Strip } from '@/pages/Strips';

interface ToolsPageProps {
  atisContext?: AtisContext;
  onAtisContextChange: (context: AtisContext) => void;
  onCreateStrip: (strip: Strip) => void;
  onUpdateStripStatus: (callsign: string, status: StatusValue) => boolean;
}

export default function ToolsPage({
  atisContext,
  onAtisContextChange,
  onCreateStrip,
  onUpdateStripStatus,
}: ToolsPageProps) {
  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
      <div className="mb-5 flex items-end justify-between">
        <div>
          <h1 className="text-xl font-semibold tracking-tight">Controller Tools</h1>
          <p className="text-sm text-muted-foreground">ATIS, airline lookup, and text phraseology for online controllers by Buckers for SAFS.</p>
        </div>
        <span className="hidden font-mono text-[10px] uppercase tracking-widest text-muted-foreground sm:inline">session state — preserved in app</span>
      </div>

      <div className="grid gap-5 lg:grid-cols-12">
        <div className="lg:col-span-7 xl:col-span-7">
          <AtisGenerator onContextChange={onAtisContextChange} />
        </div>
        <div className="grid gap-5 lg:col-span-5 xl:col-span-5">
          <AirlineLookup />
        </div>
        <div className="lg:col-span-12">
          <PhraseGenerator
            atisContext={atisContext}
            onCreateStrip={onCreateStrip}
            onUpdateStripStatus={onUpdateStripStatus}
          />
        </div>
      </div>
    </div>
  );
}
