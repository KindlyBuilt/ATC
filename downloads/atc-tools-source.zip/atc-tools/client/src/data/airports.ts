// Seed list of airports. Add more by appending to DEFAULT_AIRPORTS or via the UI.
export interface Airport {
  icao: string;
  name: string;
  city?: string;
  notForAtis?: boolean;
}

export const DEFAULT_AIRPORTS: Airport[] = [
  { icao: 'KLSX', name: 'Los Santos International Airport' },
  { icao: 'KEYW', name: 'Key West International Airport' },
  { icao: 'KGJJ', name: 'Jersey International Airport' },
  { icao: 'KZAA', name: 'Auckland International Airport' },
  { icao: 'KZAN', name: 'Fort Zancudo' },
  { icao: 'KSSI', name: 'Sandy Shores International Airport' },
  { icao: 'KSSR', name: 'Sandy Shores Regional Airport' },
  { icao: 'KMCD', name: 'Mount Chiliad Airfield' },
  { icao: 'KMCK', name: 'McKenzie Airfield' },
  { icao: 'KPIA', name: 'Procopio International Airport' },
  { icao: 'KMDW', name: 'Midway International Airport' },
  { icao: 'KSZA', name: 'Lugano Regional Airport' },
  { icao: 'KRDI', name: 'Red Dead International Airport' },
  { icao: 'KBID', name: 'Block Island State Airport' },
  { icao: 'KICJ', name: 'Palermo International Airport' },
  { icao: 'KPFC', name: 'Pacific International Airport' },
  { icao: 'VFR', name: 'VFR Local', notForAtis: true },
];

// NATO phonetic for ATIS info letter
export const PHONETIC: Record<string, string> = {
  A: 'ALPHA', B: 'BRAVO', C: 'CHARLIE', D: 'DELTA', E: 'ECHO', F: 'FOXTROT',
  G: 'GOLF', H: 'HOTEL', I: 'INDIA', J: 'JULIET', K: 'KILO', L: 'LIMA',
  M: 'MIKE', N: 'NOVEMBER', O: 'OSCAR', P: 'PAPA', Q: 'QUEBEC', R: 'ROMEO',
  S: 'SIERRA', T: 'TANGO', U: 'UNIFORM', V: 'VICTOR', W: 'WHISKEY', X: 'XRAY',
  Y: 'YANKEE', Z: 'ZULU',
};
